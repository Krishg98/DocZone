Online Doctor Appointment System (DocZone) is made using PHP and MySQL.

In this System, there're two users.
    1. Doctor
    2. Patient

## Doctor 

Firstly Doctor need to signup in the system. After that, Doctor can login their accounts using valid email and password.

doctor can see their login form using this link: http://localhost/doczone/dams/doctor/login.php

there's no other options are available in the system to login doctor module.

## Patient

Patient no need to login or signup in this system. they can directly use the system.

Patient can book new appointments, view their all appointments, contact to organization help center.

link for open website is : http://localhost/doczone/dams/index.php
