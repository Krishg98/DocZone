-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2025 at 10:09 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `damsmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblappointment`
--

CREATE TABLE `tblappointment` (
  `ID` int(10) NOT NULL,
  `AppointmentNumber` int(10) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `MobileNumber` bigint(20) DEFAULT NULL,
  `Email` varchar(250) DEFAULT NULL,
  `AppointmentDate` date DEFAULT NULL,
  `AppointmentTime` time DEFAULT NULL,
  `Specialization` varchar(250) DEFAULT NULL,
  `Doctor` int(10) DEFAULT NULL,
  `Message` mediumtext DEFAULT NULL,
  `ApplyDate` timestamp NULL DEFAULT current_timestamp(),
  `Remark` varchar(250) DEFAULT NULL,
  `Status` varchar(250) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblappointment`
--

INSERT INTO `tblappointment` (`ID`, `AppointmentNumber`, `Name`, `MobileNumber`, `Email`, `AppointmentDate`, `AppointmentTime`, `Specialization`, `Doctor`, `Message`, `ApplyDate`, `Remark`, `Status`, `UpdationDate`) VALUES
(12, 910502232, 'Harsh Patel', 9898989898, 'harsh@gmail.com', '2025-03-29', '12:12:00', '1', 1, 'its urgent', '2025-03-27 09:03:25', 'i\'m on leave', 'Cancelled', '2025-03-27 09:07:28'),
(13, 541361012, 'Harsh Patel', 9898989898, 'harsh@gmail.com', '2025-03-29', '12:12:00', '1', NULL, 'its urgent', '2025-03-27 09:04:19', NULL, NULL, NULL),
(14, 752916513, 'Dhruvil patel', 9999999999, 'dhruvil@gmail.com', '2025-03-30', '13:04:00', '1', 1, 'its important', '2025-03-27 09:05:38', 'yess we\'ll meet', 'Approved', '2025-03-27 09:07:43'),
(15, 697142907, 'Nayan Kathiriya', 7861963651, 'nayan@gmail.com', '2025-04-03', '14:30:00', '1', 1, 'hey sir! please help.', '2025-03-27 09:06:50', 'yess sure', 'Approved', '2025-03-27 09:07:59'),
(16, 381176954, 'Raj Bhojani', 8585858585, 'raju@gmail.com', '2025-04-04', '14:04:00', '1', 1, '', '2025-03-27 09:08:49', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbldoctor`
--

CREATE TABLE `tbldoctor` (
  `ID` int(5) NOT NULL,
  `FullName` varchar(250) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(250) DEFAULT NULL,
  `Specialization` varchar(250) DEFAULT NULL,
  `Password` varchar(259) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbldoctor`
--

INSERT INTO `tbldoctor` (`ID`, `FullName`, `MobileNumber`, `Email`, `Specialization`, `Password`, `CreationDate`) VALUES
(1, 'Dr.Dharmik Pansuriya', 9328159029, 'dharmik@gmail.com', '1', 'b1f2aabece87c9a1acd1075212c1985c', '2025-01-29 15:01:11'),
(2, 'Dr. Rudra Italiya', 9090999099, 'rudra@gmail.com', '2', '7f064da04f6fce39f051d75dcfc43221', '2025-01-29 15:01:59'),
(3, 'Dr. Ashvin Gohil', 8080888088, 'ashvin@gmail.com', '3', 'ddb78f010f8800bb2d45b5947e933a51', '2025-01-11 01:28:44'),
(4, 'Dr. Parth Solanki', 1231231230, 'parth@gmail.com', '4', '04788c4f5295bc48719eb9d8d3dec40d', '2025-01-11 01:54:44'),
(5, 'Dr. Hit Goyani', 3213213210, 'hit@gmail.com', '5', 'f09328d495fa622700aabe5707edf00b', '2025-03-23 15:46:14');

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` date DEFAULT NULL,
  `Timing` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`, `Timing`) VALUES
(1, 'aboutus', 'About Us', '<div><font color=\"#202124\" face=\"arial, sans-serif\"><b>Our mission is to empower Healthcare professionals to deliver exceptional care by providing a user-friendly, efficient and reliable appointment management solution.</b></font></div><div><font color=\"#202124\" face=\"arial, sans-serif\"><b><br></b></font></div><div><font color=\"#202124\" face=\"arial, sans-serif\"><b>Our team consist of experienced healthcare professionals, software developers and designers who share a passion for improving healthcare delivery. we\'re dedicated to supporting our user and continually enhancing our system to ensure it meets the highest standerds.</b></font></div>', NULL, NULL, NULL, ''),
(2, 'contactus', 'Contact Us', '211, Eva Surbhi Mall, Waghavadi road, Bhavnagar-364001', 'doczone@gmail.com', 9328159029, NULL, '9:00 AM to 7:30 PM (Monday - Saturday)');

-- --------------------------------------------------------

--
-- Table structure for table `tblspecialization`
--

CREATE TABLE `tblspecialization` (
  `ID` int(5) NOT NULL,
  `Specialization` varchar(250) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblspecialization`
--

INSERT INTO `tblspecialization` (`ID`, `Specialization`, `CreationDate`) VALUES
(1, 'Psychiatric', '2025-01-08 14:22:33'),
(2, 'Cardiologist', '2025-01-08 14:23:42'),
(3, 'Dermatologist', '2025-01-08 14:24:14'),
(4, 'General Surgeon', '2025-01-08 14:24:42'),
(5, 'Pediatrics', '2025-01-08 14:25:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblappointment`
--
ALTER TABLE `tblappointment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbldoctor`
--
ALTER TABLE `tbldoctor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblspecialization`
--
ALTER TABLE `tblspecialization`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblappointment`
--
ALTER TABLE `tblappointment`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbldoctor`
--
ALTER TABLE `tbldoctor`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblspecialization`
--
ALTER TABLE `tblspecialization`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
